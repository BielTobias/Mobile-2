import { View, Text, Image } from 'react-native';

import myImage from './assets/maui.jpg';


function App(){
  return(
    <View>
      <Image source={myImage} style={{ width: 200, height: 200, margin: 'auto'}} />
      <Text style={{ margin: 10}}>Dados pessoais:{"\n"}
      Nome: Gabriel Tobias Machado{"\n"}
      Tel: (13)98177-0374</Text>

      <Text style={{ margin: 10}}>Formação academica:{"\n"}
      Cursando Sistemas para Internet na FATECRL{"\n"}
      Tel: (13)98177-0374</Text>

      <Text style={{ margin: 10}}>Experiência:{"\n"}
      Técnico em hardware e suporte ao usuário.{"\n"}
      Tel: (13)98177-0374</Text>

      <Text style={{ margin: 10}}>Projetos:{"\n"}
      Projetos no Github: github.com/BielTobias{"\n"}
      Tel: (13)98177-0374</Text>
    </View>
  )
}

export default App;